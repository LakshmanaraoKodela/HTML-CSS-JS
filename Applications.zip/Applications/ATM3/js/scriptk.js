//document.getElementById("fPage").style.display="block";
//document.getElementById("suns").addEventListener("click",firstpage);
//document.getElementById("fPage").style.display="block";
//document.getElementById("suns").addEventListener("click",firstpage);
var load=document.getElementById("login");
var done=document.querySelector(".sPage");
load.addEventListener("click",function(){
done.style.display="block";
document.querySelector(".fPage").style.display="none";
});
var s=document.getElementById("successing");
var withdraws=document.getElementById("with");
var deposits=document.getElementById("depo");
var tabless=document.querySelector(".history");
var names=["Lakshman","Raju","Sonu"];
var accountNumbers=["1234567","987654"];
var Passwords=["1234","9876"];
var balances=[2000,30000];
var transaction=[ [],[]];
var i;
var trans;
var entermoney;
var x=document.querySelector("#suns")
x.addEventListener("click", first);
function first(){
var acc=document.querySelector(".sizes").value;
var pass=document.querySelector(".size").value;
if(accountNumbers.indexOf(acc)==-1)
{
document.querySelector("#erroring").style.display="block";
}
else if(accountNumbers.indexOf(acc)!=-1)
{
if(accountNumbers.indexOf(acc)==Passwords.indexOf(pass))
{
i=accountNumbers.indexOf(acc);
document.querySelector(".fPage").style.display="none";
document.querySelector(".sPage").style.display="none";
document.querySelector("#erroring").style.display="none";
document.querySelector(".tPage").style.display="block"; 
alert("successfully logged in");
}   
else
{
document.querySelector("#erroring").style.display="block";
}
}
} 
//document.getElementById("#logo").addEventListener("click",function(){
//	document.querySelector(".fPage").style.display="block";
//});

withdraws.addEventListener("click",function(){
document.querySelector(".Forpage").style.display="block";
document.querySelector(".tPage").style.display="none";
document.querySelector("#erroring").style.display="none";
document.getElementById("with1").onclick=function(){
var entermoneys =document.getElementById("lak1").value;
balances[i]=balances[i]-entermoneys;
alert("Available balance is" +balances[i]);
transaction[i].push({transactiontype:"withdraws",amount:+entermoneys,availbalance:balances[i]});
document.querySelector(".Forpage").style.display="none";
document.querySelector(".tPage").style.display="block";
document.querySelector("#logo").style.display="block";
document.querySelector(".add").innerHTML=balances[i];
}
});


deposits.addEventListener("click",function(){
document.querySelector(".Fivpage").style.display="block";
document.querySelector(".tPage").style.display="none";
document.getElementById("with2").onclick=function(){
var entermoney = parseInt(document.getElementById("lak2").value);
balances[i]=balances[i]+entermoney;
alert("Available balance is" +balances[i]);
transaction[i].push({transactiontype:"deposits",amount:+entermoney,availbalance:balances[i]});
document.querySelector(".Fivpage").style.display="none";
document.querySelector(".tPage").style.display="block";
document.querySelector(".add").innerHTML=balances[i];
document.querySelector(".adds").innerHTML=names[i];
}
});


function transations(type){
var trans=" ";
if(type=="withd")
{
for( var j=0;j<transaction[i].length;j++){
if(transaction[i][j].transactiontype=="withdraws"){
//	var yes=(transaction[i][j].transactiontype=="deposits")?"green":"red";
trans+=`
<tr style="background-color:red">
   <td> ${j+1} </td>
   <td> ${transaction[i][j].transactiontype} </td>
   <td> ${transaction[i][j].amount} </td>
   <td> ${transaction[i][j].availbalance} </td>
</tr>
`;
}
}
}
else if(type=="depod")
{
for( var j=0;j<transaction[i].length;j++){
if(transaction[i][j].transactiontype=="deposits"){
//	var yes=(transaction[i][j].transactiontype=="deposits")?"green":"red";
trans+=`
<tr style="background-color:green">
   <td> ${j+1} </td>
   <td> ${transaction[i][j].transactiontype} </td>
   <td> ${transaction[i][j].amount} </td>
   <td> ${transaction[i][j].availbalance} </td>
</tr>
`;
}
}
}
else{
for( var j=0;j<transaction[i].length;j++){
var lacha=(transaction[i][j].transactiontype=="deposits")?"green":"red";
trans+=`
<tr style="background-color:${ lacha}">
   <td> ${j+1} </td>
   <td> ${transaction[i][j].transactiontype} </td>
   <td> ${transaction[i][j].amount} </td>
   <td> ${transaction[i][j].availbalance} </td>
</tr>
`;
}
}

console.log("transation history is:"+trans);
document.querySelector(".sixpage").style.display="block";
document.querySelector(".tPage").style.display="none";
//alert("transation history is:"+ho);
document.querySelector(".history").innerHTML=trans;
}
document.querySelector(".close").addEventListener("click",function(){
document.querySelector(".sixpage").style.display="none";
document.querySelector(".tPage").style.display="block";
});

function quit()
{
	
document.querySelector(".fPage").style.display="block";
document.querySelector(".tPage").style.display="none";
}

document.querySelector("#logo").addEventListener("click",quit);

