
var score=20;
var highscore=0;
var secretNumber=Math.ceil(Math.random()*20)+1;
console.log(secretNumber);
document.querySelector(".scoress").textContent=score;
var flag=true;
function check()
{
       
            var guessNumber=document.querySelector(".value").value;
            if(flag==false)
            {
            alert("press Again to  restart the game");
            }
           else if(guessNumber==""){
            alert("enter a number");
            }
           else if(guessNumber>20)
           {
           alert("plaese enter numbers between 1 to 20");
           }
          
 
          else if(guessNumber==secretNumber)
           {
         
         document.querySelector(".guess").textContent="you won the game";
         console.log("you won the game");
         
          document.querySelector("body").style.backgroundColor="green";
           document.querySelector(".highscore").textContent="highscore"+score;
           document.querySelector(".number").textContent=secretNumber;
        flag=false;
           
           if(highscore<score){

            highscore=score;

            document.querySelector(".highscore").textContent= `highscore:${highscore}`;



           }else{

            highscore=highscore;

            document.querySelector(".highscore").textContent= `highscore:${highscore}`;
            
           }
            
           
           }
           
              else 
              {
              score--;
              clear();
              if(guessNumber>secretNumber)
                   { 
                    score--;
                    clear();
                      document.querySelector(".guess").textContent="Too High ";
                      document.querySelector(".scoress").textContent=score;
                       console.log("Too High");
                     }
                     
                 else if(guessNumber<secretNumber)
                     {
                        document.querySelector(".guess").textContent="Too low";
                        document.querySelector(".scoress").textContent=score;
                        console.log("Too low");
                        score--;
                     }
                      else if(typeof guessNumber=="string")
          {
           alert("enter a Number only");
          }
                     
               }
 }


function Again()
{
score=20;

secretNumber=Math.ceil(Math.random()*20)+1;
console.log(secretNumber);
document.querySelector(".highscore").textContent= `highscore:${highscore}`;
 document.querySelector(".scoress").textContent=score;
   document.querySelector(".guess").textContent="start guessing";
    document.querySelector(".number").textContent="?";
    document.querySelector("body").style.backgroundColor="black";
flag=true;
              
              }
 function clear(){
    document.querySelector(".value").value=" ";
 }

