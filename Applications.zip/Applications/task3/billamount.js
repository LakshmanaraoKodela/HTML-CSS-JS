
var section = document.querySelector(".leftSide");
var name = document.querySelector(".recipe");
var amount = document.querySelector(".price");
var action1 = document.querySelector("#clicking");
var tablecontent = document.querySelector(".tablecont");
var pricevalue = document.querySelector(".space");
var totalAmount = document.querySelector("#clicking1");
var clearData = document.querySelector(".clear");
//var inputValue = document.querySelector("#empty");
var tax = document.querySelector("#taxes");
var discounts = document.querySelector("#Discount");
var putData = document.getElementById("clicking");
var userName = document.querySelector("#phone");
var orderData = document.querySelector(".completeData");
var orderdiv = document.querySelector(".content");
var rightContent = document.querySelector(".right_side");
var top = document.querySelector(".top");
var orderNum = document.querySelector(".first");
var details=document.querySelector(".information");
var ordercount=document.querySelector(".count");
var displayContent=document.querySelector("#Current")
var  totalDisplay=document.querySelector(".totalpage");
var tableHeads=document.querySelector(".headings");
var cross=document.querySelector(".null");
var displayitem=document.querySelector(".item");
var quantityInput;
//var discountValues=document.querySelector("#Discount")
var data;
var next = 1;
var dataCont;
var itemPrices = 0;
var totalBill;
var taxAmount = 0;
var DiscountPrice;
var amount;
var jsonData1;
var jsonData2;
var discountValue = 0;

//var arr = [];
var quantityValue = [];
var quantityData;
orderNumber();
async function display() {
  section.innerHTML="";
console.log("hy")
  data = await fetch('http://localhost:3000/items');
  dataCont = await data.json();
  console.log(dataCont);
  for (var i = 0; i < dataCont.length; i++) {

    section.innerHTML +=
      `<div class="item" onclick="datav(${i})">
    <p class="recipe">${dataCont[i].name}</p>
  
    <p class="price">${dataCont[i].price}</p>
   </div> `


  }
  return dataCont;

}


display();
displayContent.addEventListener("click",display );
displayContent.addEventListener("click",blocking );

function clicks() {
  tablecontent.innerHTML ="";
  totalBill=0;
  for(var item=0;item<quantityValue.length;item++){
  tablecontent.innerHTML +=
    `<tr>
   <td>${quantityValue[item].name}</td>
     <td class="space1"><input type="number" id="empty" value="${quantityValue[item].quantity}" onchange="add('${item}')" ></td>
    <td class="space">${quantityValue[item].price*quantityValue[item].quantity}</td>
    </tr>`
  


    totalBill+=quantityValue[item].price*quantityValue[item].quantity;
  
    
  }
  console.log(totalBill);
  calcu();

}

function calcu(){
  taxAmount = (totalBill / 100) * 4;
  DiscountPrice = (totalBill / 100) * 10;
  console.log(taxAmount);
  amount = `${(totalBill + taxAmount) - DiscountPrice}`;
  totalAmount.innerHTML = amount;
  tax.innerHTML = `${taxAmount}`;
  discounts.innerHTML = `${DiscountPrice}`;
 if(next>1){
  displayitem.disabled=true;
 }

}


clearData.addEventListener("click", clearAll);

function clearAll() {
  totalAmount.innerHTML = "";
  tablecontent.innerHTML = "";
  discounts.innerHTML = 0;
  tax.innerHTML = 0;
  userName.innerHTML="";
}



orderNum.addEventListener("click", getData);

putData.addEventListener("click", postData);

async function postData() {
  alert("items Successfully selected");
  let jsonData = await fetch(' http://localhost:3000/order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      customerName: userName.value,
      discount: DiscountPrice,
      tax:taxAmount,
      billamount: amount,
      orderitems: quantityValue
    })
  })

    .then(p => { return p })
    .then(q => { console.log(q) })
    .catch(d => { console.log(d) });


  clearAll();
  orderNumber();
}



async function orderNumber(){
  let jsonData1 = await fetch(' http://localhost:3000/order');
  let jsonData2 = await jsonData1.json();
  ordercount.innerHTML=jsonData2.length;
}




function blocking(){
  orderData.style.display="none";
  details.style.display="none";
  tableHeads.style.display="none";
  section.style.display="block";
  
  rightContent.style.display="block";
}




async function getData() {
  orderData.innerHTML="";
  
  section.style.display = "none";
  orderdiv.style.display = "block";
  rightContent.style.display = "none";



   jsonData1 = await fetch(' http://localhost:3000/order');
   jsonData2 = await jsonData1.json();
  console.log(jsonData2);
  for (let r = 0; r < jsonData2.length; r++) {
    orderData.innerHTML +=
      `<tr>
  <td>${next++}</td>
  <td>${jsonData2[r].id}</td>
    <td>${jsonData2[r].customerName}</td>
    <td>${jsonData2[r].discount}</td>
    <td>${jsonData2[r].billamount}</td>
   <td><button class="clickme" onclick="view('${jsonData2[r].id}')">view</button></td>

    
  </tr>`
 
    console.log("hii");
  }

}



async function view(o){
 
var today=new Date();
var day=today.getDay();
var month=today.getMonth();
var year=today.getYear();
var h=today.getHours();
var m=today.getMinutes();
var s=today.getSeconds();

console.log(day+":"+month+":"+year);


console.log(o);

  orderData.style.display="none";
  orderdiv.style.display="none";
  details.style.display="block";
   let jsonData3 = await fetch(` http://localhost:3000/order/${o}`);
   console.log(' http://localhost:3000/order/o');
   let jsonData4 = await jsonData3.json();
  console.log(jsonData4);
 
  
 
  
    details.innerHTML=
      `<div class="bill">
      <span class="null" onclick="wrong()">&times</span>
  <center><h1>*****Order Summary*****</h1></center>
 <p> <b>DATE:</b>${today}</p>
 <p> <b>TIME:</b>${h+":"+m+":"+s}</p>
    <tr>---x---x-----x------x-----x----x----x---x-----x--x---x----x---x--x----x---</tr>
    
    <p>CUSTOMERNAME:${jsonData4.customerName}</p>`

    for(var orderNames=0;orderNames<jsonData4.orderitems.length;orderNames++){
var totalPay=jsonData4.orderitems[orderNames].price*jsonData4.orderitems[orderNames].quantity;
      details.innerHTML+=` <p>${jsonData4.orderitems[orderNames].name}=${jsonData4.orderitems[orderNames].price}*${jsonData4.orderitems[orderNames].quantity}=${totalPay}</p>`
      
    }
 

    details.innerHTML+=` 
     <p>DISCOUNT:${jsonData4.discount}</p>
    <p>TAX:${jsonData4.tax}</p>
    
    <p>TOTALBILL:${jsonData4.billamount}</p>
    
    
    <tr>----x-----x---x---x---x--x----x----x---x----x----x-x----x----x---x--x----x-</tr>
    <p>ThankYou Visit Again</p>
    <p>@copirights https\\:www.panchavati.restaurent.com </div>`


  }
 


  //cross.addEventListener("click",wrong);
 function wrong(){
  console.log("go");
  details.style.display="none";
  orderData.style.display="block";
  displayContent.addEventListener("click",display );
}







// function table() {


//   for (var p = 0; p < quantityValue.length; p++) {
//     tablecontent.innerHTML +=
//       `<tr>
//     <td>${quantityValue[p].name2}</td>
//       <td class="space1"><input type="text" id="empty" value="${quantityValue[p].quantity}" onchange=table(${p})></td>
//      <td class="space">${quantityValue[p].price * quantityValue[p].quantity}</td>
//      </tr>`
//   }
// }

function datav(arrDta){
  quantityValue.push({"name":dataCont[arrDta].name,"price":dataCont[arrDta].price,"quantity":1} );
console.log(quantityValue);

//arr.push({ name2: `${dataCont[arrDta].name}`, quantity: `${dataCont[arrDta].quantity}`, price: `${dataCont[arrDta].price}` });
//console.log(arr);
clicks();
}

function add(inputId){
  quantityInput=document.querySelectorAll("#empty");
 quantityData=quantityInput[inputId].value;
 quantityValue[inputId].quantity=`${parseInt(quantityData)}`;
 console.log(quantityData);
console.log(quantityValue[inputId].quantity);

if(quantityData<1){
  alert("please enter a valid quantity");
}


clicks();
}

//datav();




