var jsonData;
var jsonData1;
var x;
var initialvalue = "";
var nextvalue = 1;
var ten = 10;
var imgurl;
var completeData;

var link=document.querySelector(".url");
var iteams = document.querySelector(".items");
var previous = document.querySelector(".end_btn1");
var next = document.querySelector(".end_btn2");
var search = document.getElementById('buton');
var changeimg = document.querySelector(".idly1");
var imgs = document.querySelector('#img1');
var listIngradents = document.querySelector(".order");
var recipieIMg=document.querySelector(".right1");
var changeTime=document.querySelector(".svg3");
var textChange=document.querySelector(".title");


async function Display() {
	iteams.innerHTML="";
	var key = document.getElementById('place').value;
	x = await fetch(`https://forkify-api.herokuapp.com/api/v2/recipes?search=${key}`)
		// console.log(x);
		.then(async function (y) {
			jsonData = await y.json();
			initial();

			console.log(jsonData);
			console.log(y);
		})
}


function initial() {

	for (let i = (nextvalue * ten) - ten; i < nextvalue * ten; i++) {
		iteams.innerHTML +=
			`<button class="idly1" onclick="clicks('${jsonData.data.recipes[i].recipe_id}')">
		 
			<img src=${jsonData.data.recipes[i].image_url}  id="img1">
		
		<div class="content">
			<span class="head1">${jsonData.data.recipes[i].title}</span>
			
			<span class= "head2" >${jsonData.data.recipes[i].publisher} </span>
		</div>
			 </button>	`

	}

}


function nextpage() {
	previous.style.display = "block";
	iteams.innerHTML = "";

	nextvalue++;

	console.log(nextvalue);
	
	if (nextvalue == 3) {
		next.style.display = "none";

		console.log("hyy");
	}
	initial();
}




async function clicks(recipis1) {
	var chef=document.querySelector(".chefName");

	console.log(recipis1);

	


	listIngradents.innerHTML ="";
	imgurl = await fetch(`https://forkify-api.herokuapp.com/api/v2/recipes/${recipis1}?key=<insert your key>`)

		.then(async function (r) {
			jsonData1 = await r.json();
			//recipiesIngradentList(recipis1);

			console.log(jsonData1);

			for (let i = 0; i < jsonData1.data.recipe.ingredients.length; i++) {
				//listIngradents.innerHTML += `<li>${jsonData1.recipe.ingredients[i]} ${jsonData1.recipe.ingredientsdents[i]}
				// ${jsonData1.recipe[i].ingredients[i]}`;
				listIngradents.innerHTML +=`<li><img src="../images/checkicon (1).svg" id="ticks">${jsonData1.data.recipe.ingredients[i]}</li>`
		        console.log(`${jsonData1.data.recipe.ingredients[i]}`);
				recipieIMg.style.backgroundImage=`url('${jsonData1.data.recipe.image_url}')`;
					console.log(`${jsonData1.data.recipe.image_url}`);
                textChange.innerHTML=`<h2 id="verity1">'${jsonData1.data.recipe.title}'</h2>`
				
		
				console.log(`${jsonData1.data.recipe.title}`);
					//changeTime.innerHTML+= `${jsonData1.data.recipe.cooking_time[i]}`;
					//console.log(`${jsonData1.data.recipe.cooking_time[i]}`);
					chef.innerHTML=`${jsonData1.data.recipe.publisher}`;
                   console.log(`${jsonData1.data.recipe.publisher}`);






				   link.innerHTML=`${jsonData1.data.recipe.source_url}`;





				   




			}

		})
		
}
